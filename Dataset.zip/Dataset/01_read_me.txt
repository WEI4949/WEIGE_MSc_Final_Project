01_libraries
This project uses several Python libraries to support hydrological modeling with LSTM neural networks:
tensorflow.keras: to build, train, and manage LSTM models.
pandas: for data manipulation and DataFrame operations.
numpy: for numerical computing and array handling.
h5py: to save and load neural network models.
hydroeval: to evaluate hydrological model performance (e.g., KGE, NSE).
matplotlib.pyplot: for plotting and visualizing results.
datetime: for handling dates and time operations.
os: for file system operations.


02_Variables

Input Variables (Var_X)

The model uses the following 18 input variables, combining dynamic and static catchment attributes:

prec_ref: reference precipitation (dynamic)
pet_pm: potential evapotranspiration (Penman-Monteith) (dynamic)
clim_tmin, clim_tmax: minimum and maximum air temperature
clim_pmm: monthly precipitation climatology
clim_petmm_day: daily PET climatology
aridity_index: climatic aridity index
q_mean_mm: mean annual runoff (mm)
runoff_coef: runoff coefficient
baseflow_index: baseflow index
cover_urban_%, cover_crops_%: percentage of urban and crop land use
res_number: number of upstream reservoirs
hdisturb_index: human disturbance index
catch_area: catchment area
elev_mean: mean elevation
catch_slope: mean catchment slope
catch_order: stream order of the catchment
All_var_x=["prec_ref","pet_pm","clim_tmin","clim_tmax","clim_pmm",
            "clim_petmm_day","aridity_index","q_mean_mm","runoff_coef",
            "baseflow_index","cover_urban_%","cover_crops_%",
            "res_number" , "hdisturb_index","catch_area","elev_mean",
        "catch_slope","catch_order"]

Output Variable (Var_Y)

Q_mm: observed streamflow in millimeters 


Note: When training the model with data from multiple catchments, it is important to normalize or standardize the input variables. This ensures that differences in scale between catchments do not negatively affect model training and performance. It is important to use training, validation and testing. 
Sugestion data  
	Date_start_tr= "1980-10-01"
	Date_end_tr = "1998-09-30"
	Date_start_val = "1998-10-01"
	Date_end_val = "2004-09-30"
	Date_start_tes = "2004-10-01"
	Date_end_tes = "2010-09-30" 

03_Temporal Sequence Construction (3D Input Array)

To train LSTM models, input data must be structured as a three-dimensional array with the format [samples, timesteps, features]. This structure allows the model to capture temporal dependencies across input variables. Here, sequences are created based on a defined lookback window (e.g., 60 days), meaning that each training sample contains a fixed-length sequence of past observations. The lookback length is a critical hyperparameter that controls how far into the past the model can "see" to make a prediction. Proper sequence construction is essential for enabling the LSTM to learn both short- and long-term patterns relevant to hydrological behavior.



